const
  aws = require('aws-sdk'),
  uuidv4 = require('uuid/v4');
const ddb = new aws.DynamoDB({ apiVersion: '2012-10-08' });
exports.handler = function (event, context, callback) {
  var d = new Date();
  var uuidUser = uuidv4();
  var paramsUsuarios = {
    TableName: 'Usuarios',
    Item: {
      "UsuarioID": { "S": event.userName },
      "UsuarioUUID": { "S": uuidUser },
      "Nombre": { "S": event.request.userAttributes.given_name },
      "Apellido": { "S": event.request.userAttributes.family_name },
      "Email": { "S": event.request.userAttributes.email },
      "Creado": { "S": d.toISOString() },
      "Modificado": { "S": d.toISOString() }
    }
  };
  var paramsIDs = {
    TableName: 'Usuarios2',
    Item: {
      "UsuarioUUID": { "S": uuidUser },
      "NombreCompleto": { "S": event.request.userAttributes.given_name + " " + event.request.userAttributes.family_name },
      "IDTipo": { NULL: true },
      "IDNumeror": { NULL: true },
      "CreateDateTime": { "S": d.toISOString() },
      "UpdateDateTime": { "S": d.toISOString() }
    }
  };
  var usuariosPromise = ddb.putItem(paramsUsuarios).promise()
    .then(function (data) { console.log('Exito Usuarios'); return true; }
    ).catch(function (err) { console.log("Error Usuarios: " + err); return false; });
  var usuarios2Promise = ddb.putItem(paramsIDs).promise()
    .then(function (data) { console.log('Exito Usuarios2'); return true; }
    ).catch(function (err) { console.log("Error Usuarios2: " + err); return false; });
  Promise.all([usuariosPromise, usuarios2Promise])
    .then(function (values) {
      if (values[0] && values[1]) context.succeed(event);
      else context.fail("error");
      callback(null, event);
    }
    ).catch(
      function (err) {
        context.fail(err);
        callback(null, event);
      }
    );
};